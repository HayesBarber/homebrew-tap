from datetime import datetime


def today():
    return datetime.today().date()
